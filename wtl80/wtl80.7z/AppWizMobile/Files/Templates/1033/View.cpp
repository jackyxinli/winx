// [!output WTL_VIEW_FILE].cpp : implementation of the [!output WTL_VIEW_CLASS] class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//?ppc
#include "resourceppc.h"
//?sp
#include "resourcesp.h"
//?end

#include "[!output WTL_VIEW_FILE].h"

